﻿using FujinoNs.NetworkInfo;
using System.Windows;

namespace Fujino.Network.Info.API_Test
{
    public partial class MainWindow : Window
    {
        KC_NetworkInfo _NetworkInfo = new KC_NetworkInfo();
        public MainWindow()
        {
            InitializeComponent();
            lbl_1.Content += _NetworkInfo.IPAddress();
            lbl_2.Content += _NetworkInfo.Country();
            lbl_3.Content += _NetworkInfo.TimeZone();
            lbl_4.Content += _NetworkInfo.RegionName();
            lbl_5.Content += _NetworkInfo.City();
            lbl_6.Content += _NetworkInfo.ISP();
            lbl_7.Content += _NetworkInfo.Status();
        }
    }
}
