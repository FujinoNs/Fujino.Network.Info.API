﻿namespace FujinoNs.NetworkInfo
{
    class Json_Modul
    {
        public string status { get; set; }
        public string country { get; set; }
        public string countryCode { get; set; }
        public string regionName { get; set; }
        public string city { get; set; }
        public string timezone { get; set; }
        public string isp { get; set; }
        public string query { get; set; }
    }
}
